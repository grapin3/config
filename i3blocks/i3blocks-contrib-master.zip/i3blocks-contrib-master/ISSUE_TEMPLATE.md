### Expected behavior


### Actual behavior


### i3blocks config relevant to blocklet(s)


### Output of blocklet(s) when run from command line


### Output of any relevant other commands that might help diagnostics


